@extends('site.layouts.base')
@section('content')
    <div class="container">
        {!! $page->content !!}
    </div>
@endsection
