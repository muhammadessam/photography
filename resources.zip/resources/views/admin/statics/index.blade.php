@extends('admin.layouts.main')
@section('content')
    <div class="container">
        fck
    </div>
@endsection
